package com.example.modul34

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.modul34.data.AppDatabase
import com.example.modul34.data.entity.User

class EditActivity : AppCompatActivity() {
    private lateinit var fullName: EditText
    private lateinit var email: EditText
    private lateinit var nohp: EditText
    private lateinit var alamat: EditText
    private lateinit var btnsimpan: Button
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        fullName = findViewById(R.id.full_name)
        email = findViewById(R.id.email)
        nohp = findViewById(R.id.nohp)
        alamat = findViewById(R.id.alamat)
        btnsimpan = findViewById(R.id.btn_simpan)

        database = AppDatabase.getInstance(applicationContext)

        val intent = intent.extras
        if (intent!=null){
            val id = intent.getInt("id", 0)
            val user = database.userDao().get(id)

            fullName.setText(user.fullname)
            email.setText(user.email)
            nohp.setText(user.nohp)
            alamat.setText(user.alamat)
        }

        btnsimpan.setOnClickListener {
            if (fullName.text.isNotEmpty() && email.text.isNotEmpty() && nohp.text.isNotEmpty() && alamat.text.isNotEmpty()) {
                if (intent != null) {
                    // coding edit data
                    database.userDao().update(
                        User(
                            intent.getInt("id",0),
                            fullName.text.toString(),
                            email.text.toString(),
                            nohp.text.toString(),
                            alamat.text.toString()
                        )
                    )
                } else {
                    // coding data
                    database.userDao().insertAll(
                        User(
                            null,
                            fullName.text.toString(),
                            email.text.toString(),
                            nohp.text.toString(),
                            alamat.text.toString()
                        )
                    )
                }

                finish()
            } else {
                Toast.makeText(applicationContext, "Data Wajib Diisi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}